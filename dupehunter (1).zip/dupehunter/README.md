# 🔍 DupeHunter

**Fast, zero-dependency CLI tool to find and remove duplicate files from your filesystem.**

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Tests](https://img.shields.io/badge/tests-passing-brightgreen)

---

## The Problem

Duplicate files silently waste disk space — downloaded files saved twice, photos copied between folders, project assets duplicated across repos. DupeHunter finds them all in seconds, shows you exactly what's wasted, and lets you clean up safely.

## How It Works

DupeHunter uses a **three-stage pipeline** to be both fast and accurate:

```
Stage 1 → Group by file size      (instant, no I/O)
Stage 2 → Partial SHA-256 hash    (reads first 4 KB only)
Stage 3 → Full SHA-256 hash       (byte-perfect verification)
```

Only files that survive all three stages are reported as duplicates — no false positives.

---

## Installation

```bash
# From PyPI
pip install dupehunter

# From source
git clone https://github.com/yourusername/dupehunter
cd dupehunter
pip install -e ".[dev]"
```

---

## Usage

### Basic scan

```bash
dupehunter ~/Downloads
```

### Scan with options

```bash
# Ignore small files, skip logs
dupehunter ~/Documents --min-size 100KB --exclude "*.log" "*.tmp"

# Preview what would be deleted (safe)
dupehunter ~/Pictures --dry-run

# Auto-delete, keeping the copy with the shortest path
dupehunter ~/Music --auto-clean --keep shortest-path

# Keep the newest copy instead
dupehunter ~/Videos --auto-clean --keep newest

# Export a JSON report
dupehunter /mnt/data --export report.json
```

### Interactive mode

Running without `--auto-clean` enters interactive mode after the report, letting you choose file-by-file:

```
  Group 1/3:
    [0] /home/alice/Downloads/report.pdf
    [1] /home/alice/Documents/report.pdf
  Keep which file? (number / 'a' = keep all / 'q' = quit): 0
```

---

## CLI Reference

| Flag | Default | Description |
|------|---------|-------------|
| `path` | *(required)* | Directory to scan |
| `--min-size SIZE` | `1KB` | Ignore files smaller than SIZE (e.g. `5MB`) |
| `--exclude PATTERN…` | — | Skip files/dirs matching glob patterns |
| `--export FILE` | — | Write JSON report to FILE |
| `--dry-run` | `false` | Show deletions without performing them |
| `--auto-clean` | `false` | Delete duplicates automatically |
| `--keep` | `shortest-path` | Which copy to keep: `newest`, `oldest`, `shortest-path` |
| `--no-color` | `false` | Disable ANSI colors |
| `--quiet` | `false` | Suppress progress output |

---

## Example Output

```
────────────────────────────────────────────────────────────
  DupeHunter Results
────────────────────────────────────────────────────────────
  Duplicate groups : 3
  Redundant files  : 5
  Wasted space     : 142.3 MB
────────────────────────────────────────────────────────────

  Group 1  (48.2 MB each · 48.2 MB wasted)
    ✔ keep  /home/alice/Pictures/vacation.jpg
    ✖ dupe  /home/alice/Downloads/vacation.jpg

  Group 2  (32.1 MB each · 96.3 MB wasted)
    ✔ keep  /home/alice/Videos/clip.mp4
    ✖ dupe  /home/alice/Desktop/clip.mp4
    ✖ dupe  /home/alice/Backups/clip.mp4
```

---

## JSON Report Format

```json
{
  "summary": {
    "groups": 3,
    "redundant_files": 5,
    "wasted_bytes": 149200000
  },
  "groups": [
    {
      "size_bytes": 50528256,
      "files": [
        "/home/alice/Pictures/vacation.jpg",
        "/home/alice/Downloads/vacation.jpg"
      ]
    }
  ]
}
```

---

## Running Tests

```bash
pip install -e ".[dev]"
pytest
# or with coverage:
pytest --cov=src --cov-report=term-missing
```

---

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feat/my-feature`
3. Commit your changes: `git commit -m "feat: add my feature"`
4. Push and open a Pull Request

Please add tests for any new functionality.

---

## License

MIT — see [LICENSE](LICENSE) for details.
