#!/usr/bin/env python3
"""
DupeHunter CLI — Find and remove duplicate files from your filesystem.
"""

import argparse
import sys
from pathlib import Path
from .scanner import scan_duplicates
from .reporter import print_report, export_json
from .cleaner import interactive_clean, auto_clean


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dupehunter",
        description="🔍 DupeHunter — Find and remove duplicate files fast.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  dupehunter ~/Downloads
  dupehunter ~/Documents --min-size 1MB --dry-run
  dupehunter /mnt/data --export report.json
  dupehunter ~ --auto-clean --keep newest
        """,
    )

    parser.add_argument("path", type=Path, help="Root directory to scan")
    parser.add_argument(
        "--min-size",
        default="1KB",
        metavar="SIZE",
        help="Minimum file size to consider (e.g. 1KB, 5MB). Default: 1KB",
    )
    parser.add_argument(
        "--exclude",
        nargs="*",
        default=[],
        metavar="PATTERN",
        help="Glob patterns to exclude (e.g. '*.log' '.git')",
    )
    parser.add_argument(
        "--export",
        type=Path,
        metavar="FILE",
        help="Export duplicate report to a JSON file",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without deleting anything",
    )
    parser.add_argument(
        "--auto-clean",
        action="store_true",
        help="Automatically delete duplicates (keeps one copy per group)",
    )
    parser.add_argument(
        "--keep",
        choices=["newest", "oldest", "shortest-path"],
        default="shortest-path",
        help="Which copy to keep when auto-cleaning. Default: shortest-path",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored terminal output",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress output; only show summary",
    )

    return parser


def parse_size(size_str: str) -> int:
    """Parse human-readable size string to bytes."""
    units = {"B": 1, "KB": 1024, "MB": 1024**2, "GB": 1024**3}
    size_str = size_str.strip().upper()
    for unit, multiplier in sorted(units.items(), key=lambda x: -len(x[0])):
        if size_str.endswith(unit):
            return int(float(size_str[: -len(unit)]) * multiplier)
    return int(size_str)  # bare number = bytes


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.path.exists():
        print(f"❌ Path not found: {args.path}", file=sys.stderr)
        sys.exit(1)
    if not args.path.is_dir():
        print(f"❌ Not a directory: {args.path}", file=sys.stderr)
        sys.exit(1)

    try:
        min_bytes = parse_size(args.min_size)
    except ValueError:
        print(f"❌ Invalid size: {args.min_size}", file=sys.stderr)
        sys.exit(1)

    groups = scan_duplicates(
        root=args.path,
        min_size=min_bytes,
        exclude=args.exclude,
        quiet=args.quiet,
        color=not args.no_color,
    )

    if not groups:
        print("✅ No duplicates found.")
        sys.exit(0)

    print_report(groups, color=not args.no_color)

    if args.export:
        export_json(groups, args.export)
        print(f"📄 Report saved to {args.export}")

    if args.auto_clean:
        deleted = auto_clean(groups, keep=args.keep, dry_run=args.dry_run)
        verb = "Would delete" if args.dry_run else "Deleted"
        print(f"🗑️  {verb} {deleted} duplicate file(s).")
    elif not args.dry_run and not args.export:
        interactive_clean(groups)


if __name__ == "__main__":
    main()
