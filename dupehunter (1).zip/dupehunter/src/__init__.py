"""DupeHunter — duplicate file detector and cleaner."""

__version__ = "1.0.0"
__author__ = "DupeHunter Contributors"
__license__ = "MIT"
