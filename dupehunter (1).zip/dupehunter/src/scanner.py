"""
scanner.py — Walk a directory tree and group files by content hash.
"""

import hashlib
import os
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional
import fnmatch


CHUNK_SIZE = 65_536  # 64 KB read chunks for hashing


def _matches_any(path: Path, patterns: List[str]) -> bool:
    """Return True if path matches any glob pattern."""
    name = path.name
    parts = path.parts
    for pattern in patterns:
        if fnmatch.fnmatch(name, pattern):
            return True
        if any(fnmatch.fnmatch(p, pattern) for p in parts):
            return True
    return False


def _fast_hash(path: Path) -> Optional[str]:
    """
    Two-pass hash:
      1. Hash only the first + last 4 KB (cheap precheck).
      2. If a collision candidate is found, full SHA-256 (accurate).
    Returns hex digest or None on read error.
    """
    return _sha256(path)


def _sha256(path: Path) -> Optional[str]:
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while chunk := f.read(CHUNK_SIZE):
                h.update(chunk)
        return h.hexdigest()
    except (OSError, PermissionError):
        return None


def _partial_hash(path: Path, size: int = 4096) -> Optional[str]:
    """Hash first N bytes only — used as a quick pre-filter."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            h.update(f.read(size))
        return h.hexdigest()
    except (OSError, PermissionError):
        return None


def _collect_files(
    root: Path,
    min_size: int,
    exclude: List[str],
    quiet: bool,
    color: bool,
) -> List[Path]:
    """Walk root and collect all regular files above min_size."""
    files = []
    skip_dirs = {".git", "__pycache__", "node_modules", ".DS_Store"}

    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        # Prune excluded / hidden dirs in-place
        dirnames[:] = [
            d
            for d in dirnames
            if d not in skip_dirs and not _matches_any(Path(dirpath) / d, exclude)
        ]

        for filename in filenames:
            fp = Path(dirpath) / filename
            if _matches_any(fp, exclude):
                continue
            try:
                if fp.stat().st_size >= min_size:
                    files.append(fp)
            except OSError:
                pass

    if not quiet:
        tag = "\033[36m" if color else ""
        reset = "\033[0m" if color else ""
        print(f"{tag}🔎 Found {len(files):,} files to analyse…{reset}", file=sys.stderr)

    return files


def scan_duplicates(
    root: Path,
    min_size: int = 1024,
    exclude: List[str] = None,
    quiet: bool = False,
    color: bool = True,
) -> List[List[Path]]:
    """
    Return a list of duplicate groups.
    Each group is a list of Path objects that share the same content.
    """
    exclude = exclude or []
    files = _collect_files(root, min_size, exclude, quiet, color)

    # --- Stage 1: group by file size (fast) ---
    by_size: Dict[int, List[Path]] = defaultdict(list)
    for fp in files:
        try:
            by_size[fp.stat().st_size].append(fp)
        except OSError:
            pass

    candidates = [group for group in by_size.values() if len(group) > 1]

    if not quiet:
        tag = "\033[33m" if color else ""
        reset = "\033[0m" if color else ""
        total = sum(len(g) for g in candidates)
        print(
            f"{tag}⚡ {total:,} files share a size — computing hashes…{reset}",
            file=sys.stderr,
        )

    # --- Stage 2: partial hash pre-filter ---
    by_partial: Dict[str, List[Path]] = defaultdict(list)
    for group in candidates:
        for fp in group:
            ph = _partial_hash(fp)
            if ph:
                by_partial[ph].append(fp)

    partial_candidates = [g for g in by_partial.values() if len(g) > 1]

    # --- Stage 3: full SHA-256 ---
    by_hash: Dict[str, List[Path]] = defaultdict(list)
    done = 0
    total_to_hash = sum(len(g) for g in partial_candidates)

    for group in partial_candidates:
        for fp in group:
            full = _sha256(fp)
            if full:
                by_hash[full].append(fp)
            done += 1
            if not quiet and total_to_hash > 0:
                pct = done * 100 // total_to_hash
                bar = ("█" * (pct // 5)).ljust(20)
                print(
                    f"\r  [{bar}] {pct:3d}%  ({done:,}/{total_to_hash:,})",
                    end="",
                    flush=True,
                    file=sys.stderr,
                )

    if not quiet and total_to_hash > 0:
        print(file=sys.stderr)

    duplicates = [
        sorted(paths, key=lambda p: (len(str(p)), str(p)))
        for paths in by_hash.values()
        if len(paths) > 1
    ]

    # Sort groups by wasted space descending
    duplicates.sort(
        key=lambda g: g[0].stat().st_size * (len(g) - 1), reverse=True
    )

    return duplicates
