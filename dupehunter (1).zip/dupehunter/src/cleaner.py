"""
cleaner.py — Delete duplicate files, keeping one copy per group.
"""

import sys
from pathlib import Path
from typing import List


def _pick_keeper(group: List[Path], keep: str) -> Path:
    """Choose which file to keep from a duplicate group."""
    if keep == "newest":
        return max(group, key=lambda p: p.stat().st_mtime)
    elif keep == "oldest":
        return min(group, key=lambda p: p.stat().st_mtime)
    else:  # shortest-path (default)
        return min(group, key=lambda p: (len(str(p)), str(p)))


def auto_clean(
    groups: List[List[Path]],
    keep: str = "shortest-path",
    dry_run: bool = False,
) -> int:
    """Delete all but one file in each group. Returns count of deleted files."""
    deleted = 0
    for group in groups:
        keeper = _pick_keeper(group, keep)
        for fp in group:
            if fp == keeper:
                continue
            if dry_run:
                print(f"  [dry-run] would delete: {fp}")
            else:
                try:
                    fp.unlink()
                    print(f"  🗑️  deleted: {fp}")
                    deleted += 1
                except OSError as e:
                    print(f"  ⚠️  could not delete {fp}: {e}", file=sys.stderr)
    return deleted


def interactive_clean(groups: List[List[Path]]) -> None:
    """Prompt the user group by group to choose what to delete."""
    print("\n🧹 Interactive cleanup mode (Ctrl+C to quit)\n")

    for i, group in enumerate(groups, 1):
        print(f"  Group {i}/{len(groups)}:")
        for j, fp in enumerate(group):
            mtime = fp.stat().st_mtime if fp.exists() else 0
            print(f"    [{j}] {fp}")

        print("  Keep which file? (number / 'a' = keep all / 'q' = quit): ", end="")
        try:
            choice = input().strip().lower()
        except (KeyboardInterrupt, EOFError):
            print("\nAborted.")
            return

        if choice == "q":
            return
        if choice == "a":
            continue

        try:
            keep_idx = int(choice)
            if not 0 <= keep_idx < len(group):
                raise ValueError
        except ValueError:
            print("  ⚠️  Invalid choice, skipping group.")
            continue

        for j, fp in enumerate(group):
            if j != keep_idx:
                try:
                    fp.unlink()
                    print(f"  🗑️  deleted: {fp}")
                except OSError as e:
                    print(f"  ⚠️  {e}", file=sys.stderr)

        print()
