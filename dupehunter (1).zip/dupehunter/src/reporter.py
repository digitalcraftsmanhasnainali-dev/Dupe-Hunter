"""
reporter.py — Human-readable and JSON reporting of duplicate groups.
"""

import json
from pathlib import Path
from typing import List


def _human_bytes(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def print_report(groups: List[List[Path]], color: bool = True) -> None:
    """Print a pretty duplicate report to stdout."""
    total_files = sum(len(g) - 1 for g in groups)
    total_wasted = sum(
        g[0].stat().st_size * (len(g) - 1)
        for g in groups
        if g[0].exists()
    )

    R = "\033[31m" if color else ""
    G = "\033[32m" if color else ""
    Y = "\033[33m" if color else ""
    C = "\033[36m" if color else ""
    B = "\033[1m" if color else ""
    DIM = "\033[2m" if color else ""
    RST = "\033[0m" if color else ""

    print()
    print(f"{B}{'─' * 60}{RST}")
    print(f"{B}  DupeHunter Results{RST}")
    print(f"{B}{'─' * 60}{RST}")
    print(f"  {R}Duplicate groups : {len(groups):,}{RST}")
    print(f"  {Y}Redundant files  : {total_files:,}{RST}")
    print(f"  {R}Wasted space     : {_human_bytes(total_wasted)}{RST}")
    print(f"{B}{'─' * 60}{RST}")
    print()

    for i, group in enumerate(groups, 1):
        size = group[0].stat().st_size if group[0].exists() else 0
        wasted = size * (len(group) - 1)
        print(f"  {C}{B}Group {i}{RST}  {DIM}({_human_bytes(size)} each · {_human_bytes(wasted)} wasted){RST}")
        for j, fp in enumerate(group):
            marker = f"{G}✔ keep{RST}" if j == 0 else f"{R}✖ dupe{RST}"
            print(f"    {marker}  {fp}")
        print()


def export_json(groups: List[List[Path]], output: Path) -> None:
    """Write duplicate groups to a JSON file."""
    data = {
        "summary": {
            "groups": len(groups),
            "redundant_files": sum(len(g) - 1 for g in groups),
            "wasted_bytes": sum(
                g[0].stat().st_size * (len(g) - 1)
                for g in groups
                if g[0].exists()
            ),
        },
        "groups": [
            {
                "size_bytes": g[0].stat().st_size if g[0].exists() else 0,
                "files": [str(p) for p in g],
            }
            for g in groups
        ],
    }

    with open(output, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
