"""
tests/test_scanner.py — Unit tests for the duplicate scanner.
"""

import os
import tempfile
from pathlib import Path
import pytest
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from scanner import scan_duplicates, _partial_hash, _sha256, _matches_any
from reporter import _human_bytes
from cleaner import _pick_keeper, auto_clean


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def make_tree(tmp: Path, files: dict) -> None:
    """Write a dict of {relative_path: bytes_content} into tmp."""
    for rel, content in files.items():
        fp = tmp / rel
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_bytes(content)


# ─────────────────────────────────────────────
# scanner tests
# ─────────────────────────────────────────────

class TestScanDuplicates:
    def test_finds_identical_files(self, tmp_path):
        make_tree(tmp_path, {
            "a/file1.txt": b"hello world",
            "b/file2.txt": b"hello world",
        })
        groups = scan_duplicates(tmp_path, min_size=1, quiet=True)
        assert len(groups) == 1
        assert len(groups[0]) == 2

    def test_ignores_unique_files(self, tmp_path):
        make_tree(tmp_path, {
            "a.txt": b"foo",
            "b.txt": b"bar",
        })
        groups = scan_duplicates(tmp_path, min_size=1, quiet=True)
        assert groups == []

    def test_min_size_filter(self, tmp_path):
        make_tree(tmp_path, {
            "small1.txt": b"hi",
            "small2.txt": b"hi",
        })
        # With min_size=100, these 2-byte files should be ignored
        groups = scan_duplicates(tmp_path, min_size=100, quiet=True)
        assert groups == []

    def test_multiple_groups(self, tmp_path):
        make_tree(tmp_path, {
            "g1a.bin": b"AAAA" * 300,
            "g1b.bin": b"AAAA" * 300,
            "g2a.bin": b"BBBB" * 300,
            "g2b.bin": b"BBBB" * 300,
        })
        groups = scan_duplicates(tmp_path, min_size=1, quiet=True)
        assert len(groups) == 2

    def test_exclude_pattern(self, tmp_path):
        make_tree(tmp_path, {
            "keep/file.txt": b"same content",
            "logs/file.txt": b"same content",
        })
        groups = scan_duplicates(tmp_path, min_size=1, exclude=["logs"], quiet=True)
        assert groups == []

    def test_three_copies(self, tmp_path):
        content = b"triplicate" * 100
        make_tree(tmp_path, {
            "x/a.dat": content,
            "y/b.dat": content,
            "z/c.dat": content,
        })
        groups = scan_duplicates(tmp_path, min_size=1, quiet=True)
        assert len(groups) == 1
        assert len(groups[0]) == 3


# ─────────────────────────────────────────────
# hashing tests
# ─────────────────────────────────────────────

class TestHashing:
    def test_sha256_stable(self, tmp_path):
        fp = tmp_path / "f.bin"
        fp.write_bytes(b"stable content 123")
        assert _sha256(fp) == _sha256(fp)

    def test_sha256_differs_on_different_content(self, tmp_path):
        a = tmp_path / "a.bin"
        b = tmp_path / "b.bin"
        a.write_bytes(b"content A")
        b.write_bytes(b"content B")
        assert _sha256(a) != _sha256(b)

    def test_partial_hash_returns_string(self, tmp_path):
        fp = tmp_path / "f.txt"
        fp.write_bytes(b"x" * 1000)
        result = _partial_hash(fp)
        assert isinstance(result, str) and len(result) == 64


# ─────────────────────────────────────────────
# reporter tests
# ─────────────────────────────────────────────

class TestHumanBytes:
    def test_bytes(self):
        assert _human_bytes(512) == "512.0 B"

    def test_kilobytes(self):
        assert _human_bytes(1024) == "1.0 KB"

    def test_megabytes(self):
        assert _human_bytes(1024 ** 2) == "1.0 MB"

    def test_gigabytes(self):
        assert _human_bytes(1024 ** 3) == "1.0 GB"


# ─────────────────────────────────────────────
# cleaner tests
# ─────────────────────────────────────────────

class TestPickKeeper:
    def test_shortest_path(self, tmp_path):
        a = tmp_path / "a" / "b" / "c" / "file.txt"
        b = tmp_path / "file.txt"
        a.parent.mkdir(parents=True)
        a.write_bytes(b"x")
        b.write_bytes(b"x")
        assert _pick_keeper([a, b], "shortest-path") == b

    def test_newest(self, tmp_path):
        old = tmp_path / "old.txt"
        new = tmp_path / "new.txt"
        old.write_bytes(b"x")
        new.write_bytes(b"x")
        os.utime(old, (1000, 1000))
        os.utime(new, (9999999999, 9999999999))
        assert _pick_keeper([old, new], "newest") == new

    def test_oldest(self, tmp_path):
        old = tmp_path / "old.txt"
        new = tmp_path / "new.txt"
        old.write_bytes(b"x")
        new.write_bytes(b"x")
        os.utime(old, (1000, 1000))
        os.utime(new, (9999999999, 9999999999))
        assert _pick_keeper([old, new], "oldest") == old


class TestAutoClean:
    def test_deletes_duplicates(self, tmp_path):
        content = b"duplicate content" * 100
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_bytes(content)
        b.write_bytes(content)
        deleted = auto_clean([[a, b]], keep="shortest-path", dry_run=False)
        assert deleted == 1
        # One of them should still exist
        assert a.exists() or b.exists()
        assert not (a.exists() and b.exists())

    def test_dry_run_does_not_delete(self, tmp_path):
        content = b"dry run test" * 100
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_bytes(content)
        b.write_bytes(content)
        deleted = auto_clean([[a, b]], keep="shortest-path", dry_run=True)
        assert deleted == 0
        assert a.exists() and b.exists()


# ─────────────────────────────────────────────
# glob pattern matching
# ─────────────────────────────────────────────

class TestMatchesAny:
    def test_matches_extension(self):
        assert _matches_any(Path("/foo/bar/baz.log"), ["*.log"])

    def test_matches_dir_name(self):
        assert _matches_any(Path("/project/.git/config"), [".git"])

    def test_no_match(self):
        assert not _matches_any(Path("/foo/bar.txt"), ["*.log", ".git"])
