# Changelog

All notable changes to DupeHunter are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] — 2026-03-26

### Added
- Three-stage deduplication pipeline (size → partial hash → full SHA-256)
- `--auto-clean` mode with `--keep newest / oldest / shortest-path`
- Interactive cleanup mode (prompted, group by group)
- `--export` flag to write JSON reports
- `--dry-run` flag to preview without deleting
- `--exclude` glob patterns for files and directories
- `--min-size` filter with human-readable units (KB, MB, GB)
- Colour terminal output (disable with `--no-color`)
- Progress bar during hashing phase
- Full test suite (pytest, 100% module coverage)
- GitHub Actions CI matrix (Python 3.9–3.12, Ubuntu/macOS/Windows)
